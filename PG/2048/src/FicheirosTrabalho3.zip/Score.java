
/**
 * Each object of this class is a row of best scores table.
 */
public class Score {
    public String name;
    public int points;

    public Score(String name, int points) {
        this.name = name;
        this.points = points;
    }
}

